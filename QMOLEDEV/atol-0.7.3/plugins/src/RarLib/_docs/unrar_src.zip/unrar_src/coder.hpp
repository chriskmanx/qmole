/****************************************************************************
 *  Contents: 'Carryless rangecoder' by Dmitry Subbotin                     *
 ****************************************************************************/
#ifndef RAR_CODER_HPP__
#define RAR_CODER_HPP__

#include "rartypes.hpp"
#include "unpack.hpp"

const uint TOP=1 << 24, BOT=1 << 15;

class RangeCoder
{
  public:
    void InitDecoder(Unpack *UnpackRead);
    inline int GetCurrentCount();
    inline uint GetCurrentShiftCount(uint SHIFT);
    inline void Decode();
    inline void PutChar(unsigned int c);
    inline unsigned int GetChar();

    uint low, code, range;
    struct SUBRANGE 
    {
      uint LowCount, HighCount, scale;
    } SubRange;

    Unpack *UnpackRead;
};

#endif //RAR_CODER_HPP__