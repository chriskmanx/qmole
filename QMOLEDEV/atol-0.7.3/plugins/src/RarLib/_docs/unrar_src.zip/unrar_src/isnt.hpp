#ifndef _RAR_ISNT_
#define _RAR_ISNT_

int WinNT();

#endif
