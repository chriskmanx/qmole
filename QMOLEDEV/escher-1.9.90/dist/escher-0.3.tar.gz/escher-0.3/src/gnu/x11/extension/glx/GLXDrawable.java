package gnu.x11.extension.glx;

public interface GLXDrawable {

  int id ();
}
