package gnu.x11.extension.render;


/** Color trapezoid in RENDER. */
public class ColorTrapezoid {
  public ColorSpan top, bottom;
}
