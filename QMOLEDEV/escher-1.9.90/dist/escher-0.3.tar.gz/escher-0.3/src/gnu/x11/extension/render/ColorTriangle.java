package gnu.x11.extension.render;


/** Color trinangle in RENDER. */
public class ColorTriangle extends Triangle {
  public int red, green, blue, alpha;
}
