package gnu.x11.extension.render;


/** Span in RENDER. */
public class Span {
  public int left, right, y;
}
