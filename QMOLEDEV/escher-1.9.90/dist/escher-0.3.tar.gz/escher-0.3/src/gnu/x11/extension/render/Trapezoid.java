package gnu.x11.extension.render;


/** Trapezoid in RENDER. */
public class Trapezoid {
  public Span top, bottom;
}
