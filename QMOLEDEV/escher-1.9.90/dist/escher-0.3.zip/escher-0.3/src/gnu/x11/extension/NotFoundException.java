package gnu.x11.extension;


public class NotFoundException extends Exception {
  public NotFoundException(String s) { super(s); }
}
