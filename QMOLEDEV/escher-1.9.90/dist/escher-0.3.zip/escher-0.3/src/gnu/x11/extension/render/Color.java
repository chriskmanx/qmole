package gnu.x11.extension.render;


/** Color in RENDER. */
public class Color {
  public int red, green, blue, alpha;
}
