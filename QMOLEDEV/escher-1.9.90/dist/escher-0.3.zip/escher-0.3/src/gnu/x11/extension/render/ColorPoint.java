package gnu.x11.extension.render;


/** Color point in RENDER. */
public class ColorPoint extends gnu.x11.Point {
  public int red, green, blue, alpha;
}
