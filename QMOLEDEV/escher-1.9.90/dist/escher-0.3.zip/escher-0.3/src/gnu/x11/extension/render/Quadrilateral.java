package gnu.x11.extension.render;


/** Quadrilateral in RENDER. */
public class Quadrilateral {
  public int p1, p2, p3, p4;
}
