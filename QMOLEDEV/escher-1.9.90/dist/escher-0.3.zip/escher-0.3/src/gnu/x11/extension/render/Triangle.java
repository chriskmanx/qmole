package gnu.x11.extension.render;


/** Trinangle in RENDER. */
public class Triangle {
  public int p1, p2, p3;
}
